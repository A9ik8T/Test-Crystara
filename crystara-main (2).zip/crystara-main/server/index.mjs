import express from "express";
import crypto from "crypto";
import Razorpay from "razorpay";
import cors from "cors";
import "dotenv/config";
import { createClient } from "@supabase/supabase-js";

const app = express();

// ─── Supabase client (single shared instance) 
const supabase = createClient(
  process.env.SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: { persistSession: false },          
    global: { fetch: fetch },
    db: { schema: "public" },
  }
);

// ─── CORS 
const allowedOrigins = (process.env.CORS_ORIGIN || "")
  .split(",")
  .map((o) => o.trim())
  .filter(Boolean);

if (!allowedOrigins.length) {
  allowedOrigins.push(
    "https://www.crystara.co.in",
    "https://crystara-frontend.vercel.app",
    "https://crystara-backend.vercel.app",
    "http://localhost:8080",
    "http://localhost:5173"
  );
}

app.use(
  cors({
    origin: (origin, callback) => {
      // allow server-to-server calls (no Origin header) and listed origins
      if (!origin || allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error(`CORS: origin ${origin} not allowed`));
      }
    },
    methods: ["GET", "POST", "PATCH", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
    credentials: true,
  })
);

// ─── Body parser 
app.use(express.json({ limit: "1mb" }));   

// ─── Rate limiter  
const rateLimitMap = new Map();
const RATE_LIMIT_WINDOW_MS = 60_000;  
const RATE_LIMIT_MAX = 100;            

// Prune stale entries every minute to avoid memory leaks under heavy traffic
setInterval(() => {
  const now = Date.now();
  for (const [ip, entry] of rateLimitMap) {
    if (now - entry.windowStart > RATE_LIMIT_WINDOW_MS) rateLimitMap.delete(ip);
  }
}, RATE_LIMIT_WINDOW_MS);

function rateLimiter(req, res, next) {
  const ip = req.headers["x-forwarded-for"]?.split(",")[0]?.trim() || req.ip;
  const now = Date.now();
  const entry = rateLimitMap.get(ip);

  if (!entry || now - entry.windowStart > RATE_LIMIT_WINDOW_MS) {
    rateLimitMap.set(ip, { windowStart: now, count: 1 });
    return next();
  }

  entry.count += 1;
  if (entry.count > RATE_LIMIT_MAX) {
    return res.status(429).json({ error: "Too many requests – please slow down" });
  }
  next();
}

// Apply rate limiter globally
app.use(rateLimiter);

// ─── Razorpay ─────────────────────────────────────────────────────────────────
const keyId = process.env.RAZORPAY_KEY_ID;
const keySecret = process.env.RAZORPAY_KEY_SECRET;

if (!keyId || !keySecret) {
  console.warn(
    "[razorpay] RAZORPAY_KEY_ID or RAZORPAY_KEY_SECRET not set. " +
      "Payment endpoints will fail until they are configured."
  );
}

let razorpayInstance = null;
function getRazorpay() {
  if (!razorpayInstance) {
    razorpayInstance = new Razorpay({ key_id: keyId, key_secret: keySecret });
  }
  return razorpayInstance;
}

// ─── Auth middleware ───────────────────────────────────────────────────────────
async function verifyAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Missing or malformed authorization header" });
    }

    const token = authHeader.slice(7);
    const { data: { user }, error } = await supabase.auth.getUser(token);

    if (error || !user) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error: "Unauthorized" });
  }
}

// ─── Admin middleware ──────────────────────────────────────────────────────────
async function verifyAdmin(req, res, next) {
  try {
    const { data: profile, error } = await supabase
      .from("user_profiles")
      .select("role")
      .eq("user_id", req.user.id)
      .single();

    if (error || profile?.role !== "admin") {
      return res.status(403).json({ error: "Admin access required" });
    }
    next();
  } catch {
    return res.status(403).json({ error: "Access denied" });
  }
}

// ─── Routes ───────────────────────────────────────────────────────────────────

// Health check – useful for load-balancer probes
app.get("/health", (_req, res) => res.json({ status: "ok" }));

// Create Razorpay order
app.post("/create-order", async (req, res) => {
  try {
    const { amount, currency = "INR", receipt, notes } = req.body || {};

    if (!amount || Number.isNaN(Number(amount))) {
      return res.status(400).json({ error: "Invalid amount" });
    }

    const razorpay = getRazorpay();
    const order = await razorpay.orders.create({
      amount: Math.round(Number(amount) * 100),
      currency,
      receipt: receipt || `receipt_${Date.now()}`,
      notes: notes || {},
    });

    return res.json(order);
  } catch (error) {
    console.error("[razorpay] Error creating order:", error);
    return res.status(500).json({ error: "Failed to create order" });
  }
});

// Verify payment signature
app.post("/verify-payment", (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } =
      req.body || {};

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res.status(400).json({ valid: false, error: "Missing payment fields" });
    }

    const generatedSignature = crypto
      .createHmac("sha256", keySecret || "")
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest("hex");

    if (generatedSignature === razorpay_signature) {
      return res.json({ valid: true });
    }

    return res.status(400).json({ valid: false, error: "Invalid signature" });
  } catch (error) {
    console.error("[razorpay] Error verifying payment:", error);
    return res.status(500).json({ valid: false, error: "Verification failed" });
  }
});

// Create order record after payment
app.post("/orders", verifyAuth, async (req, res) => {
  try {
    const { orderId, paymentId, amount, items, shippingAddress, status = "completed" } =
      req.body;

    if (!orderId || !paymentId || !amount || !items) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    const { data, error } = await supabase
      .from("orders")
      .insert([
        {
          user_id: req.user.id,
          order_id: orderId,
          payment_id: paymentId,
          amount,
          items,
          shipping_address: shippingAddress,
          status,
          created_at: new Date().toISOString(),
        },
      ])
      .select();

    if (error) return res.status(400).json({ error: error.message });

    return res.json({ success: true, order: data[0] });
  } catch (error) {
    console.error("[orders] Error creating order:", error);
    return res.status(500).json({ error: "Failed to create order record" });
  }
});

// Get user's order history
app.get("/orders/user/history", verifyAuth, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("orders")
      .select("*")
      .eq("user_id", req.user.id)
      .order("created_at", { ascending: false });

    if (error) return res.status(400).json({ error: error.message });

    return res.json({ orders: data });
  } catch (error) {
    console.error("[orders] Error fetching user orders:", error);
    return res.status(500).json({ error: "Failed to fetch orders" });
  }
});

// Get single order details
app.get("/orders/:id", verifyAuth, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("orders")
      .select("*")
      .eq("id", req.params.id)
      .eq("user_id", req.user.id)
      .single();

    if (error) return res.status(404).json({ error: "Order not found" });

    return res.json({ order: data });
  } catch (error) {
    console.error("[orders] Error fetching order:", error);
    return res.status(500).json({ error: "Failed to fetch order" });
  }
});

// Admin: Get all orders (paginated)
// FIX: /admin/orders/stats/overview was shadowed by /admin/orders/:id – moved stats route first
app.get("/admin/orders/stats/overview", verifyAuth, verifyAdmin, async (req, res) => {
  try {
    const { data: orders, error } = await supabase
      .from("orders")
      .select("status,amount");

    if (error) return res.status(400).json({ error: error.message });

    const stats = {
      totalOrders: orders.length,
      totalRevenue: orders.reduce((sum, order) => sum + order.amount, 0),
      completedOrders: orders.filter((o) => o.status === "completed").length,
      pendingOrders: orders.filter((o) => o.status === "pending").length,
      failedOrders: orders.filter((o) => o.status === "failed").length,
    };

    return res.json(stats);
  } catch (error) {
    console.error("[admin] Error fetching stats:", error);
    return res.status(500).json({ error: "Failed to fetch statistics" });
  }
});

app.get("/admin/orders", verifyAuth, verifyAdmin, async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 20));
    const { status, userId } = req.query;

    let query = supabase
      .from("orders")
      .select("*,user_profiles(email,name)", { count: "exact" });

    if (status) query = query.eq("status", status);
    if (userId) query = query.eq("user_id", userId);

    const { data, error, count } = await query
      .order("created_at", { ascending: false })
      .range((page - 1) * limit, page * limit - 1);

    if (error) return res.status(400).json({ error: error.message });

    return res.json({
      orders: data,
      pagination: {
        page,
        limit,
        total: count,
        totalPages: Math.ceil(count / limit),
      },
    });
  } catch (error) {
    console.error("[admin] Error fetching orders:", error);
    return res.status(500).json({ error: "Failed to fetch orders" });
  }
});

// Admin: Update order status
app.patch("/admin/orders/:id", verifyAuth, verifyAdmin, async (req, res) => {
  try {
    const { status } = req.body;
    if (!status) return res.status(400).json({ error: "Status is required" });

    const { data, error } = await supabase
      .from("orders")
      .update({ status, updated_at: new Date().toISOString() })
      .eq("id", req.params.id)
      .select();

    if (error) return res.status(400).json({ error: error.message });

    return res.json({ success: true, order: data[0] });
  } catch (error) {
    console.error("[admin] Error updating order:", error);
    return res.status(500).json({ error: "Failed to update order" });
  }
});

// Save onboarding profile
app.post("/onboarding/profile", verifyAuth, async (req, res) => {
  try {
    const { name, phone, address_street, address_city, address_state, address_pincode } =
      req.body;

    if (!name || !phone) {
      return res.status(400).json({ error: "Name and phone are required" });
    }

    const { data, error } = await supabase
      .from("user_profiles")
      .upsert(
        {
          user_id: req.user.id,
          email: req.user.email,
          name,
          phone,
          address_street: address_street || null,
          address_city: address_city || null,
          address_state: address_state || null,
          address_pincode: address_pincode || null,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "user_id" }
      )
      .select();

    if (error) return res.status(400).json({ error: error.message });

    return res.json({ success: true, profile: data[0] });
  } catch (error) {
    console.error("[onboarding] Error saving profile:", error);
    return res.status(500).json({ error: "Failed to save profile" });
  }
});

// Check onboarding status
app.get("/onboarding/status", verifyAuth, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("user_profiles")
      .select("name")
      .eq("user_id", req.user.id)
      .single();

    if (error || !data?.name) return res.json({ isOnboarded: false });

    return res.json({ isOnboarded: true });
  } catch {
    return res.json({ isOnboarded: false });
  }
});

// Get user profile
app.get("/profile", verifyAuth, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("user_profiles")
      .select("*")
      .eq("user_id", req.user.id)
      .single();

    if (error) return res.status(404).json({ error: "Profile not found" });

    return res.json({ profile: data });
  } catch (error) {
    console.error("[profile] Error fetching profile:", error);
    return res.status(500).json({ error: "Failed to fetch profile" });
  }
});

// Update user profile
app.patch("/profile", verifyAuth, async (req, res) => {
  try {
    const {
      name, phone,
      address_street, address_city, address_state, address_pincode,
      saved_addresses,
    } = req.body;

    const updates = { updated_at: new Date().toISOString() };
    if (name !== undefined) updates.name = name;
    if (phone !== undefined) updates.phone = phone;
    if (address_street !== undefined) updates.address_street = address_street;
    if (address_city !== undefined) updates.address_city = address_city;
    if (address_state !== undefined) updates.address_state = address_state;
    if (address_pincode !== undefined) updates.address_pincode = address_pincode;
    if (saved_addresses !== undefined) updates.saved_addresses = saved_addresses;

    const { data, error } = await supabase
      .from("user_profiles")
      .update(updates)
      .eq("user_id", req.user.id)
      .select();

    if (error) return res.status(400).json({ error: error.message });

    return res.json({ success: true, profile: data[0] });
  } catch (error) {
    console.error("[profile] Error updating profile:", error);
    return res.status(500).json({ error: "Failed to update profile" });
  }
});

// ─── Global error handler ─────────────────────────────────────────────────────
// FIX: Without this, unhandled promise rejections that bubble out of Express
// middleware will crash the process under Node <15 or print unhandled rejection
// warnings.  This catches them and returns a clean 500.
// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  console.error("[server] Unhandled error:", err);
  res.status(500).json({ error: "Internal server error" });
});

// ─── Graceful shutdown ────────────────────────────────────────────────────────
// FIX: Without SIGTERM / SIGINT handling, a process manager (PM2, Docker, k8s)
// forcibly kills the process mid-request when it needs to restart the server,
// dropping in-flight requests.
let server;

function shutdown(signal) {
  console.log(`[server] Received ${signal}, shutting down gracefully…`);
  server.close(() => {
    console.log("[server] All connections closed. Exiting.");
    process.exit(0);
  });

  // Force-exit after 10 s if connections are still open
  setTimeout(() => {
    console.error("[server] Forced exit after timeout.");
    process.exit(1);
  }, 10_000);
}

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));

// ─── Catch unhandled promise rejections so the process does not crash ─────────
process.on("unhandledRejection", (reason) => {
  console.error("[server] Unhandled promise rejection:", reason);
});

process.on("uncaughtException", (err) => {
  console.error("[server] Uncaught exception:", err);
  // Keep running — log and continue.  For truly fatal errors you may want to
  // exit and let the process manager restart, but a single bad request should
  // not take down the whole server.
});

// ─── Start ────────────────────────────────────────────────────────────────────
const port = process.env.PORT || 5001;
server = app.listen(port, () => {
  console.log(`[server] Listening on http://localhost:${port}`);
});
